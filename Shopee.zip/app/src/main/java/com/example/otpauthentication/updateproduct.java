package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class updateproduct extends AppCompatActivity {

    EditText et1,et2;
    Button btn;
    String newprice,newstock;
    FirebaseFirestore fb;
    DocumentReference dref;
    String oldprice,oldStock,tmp1,tmp2;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String number,shopid,branch;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updateproduct);

        Intent i=getIntent();
        final String name=i.getStringExtra("document");
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();

        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");
        et1=findViewById(R.id.prdtupdateext1);
        et2=findViewById(R.id.prdtupdateext2);
        btn=findViewById(R.id.prdtupdatebtn);
        fb=FirebaseFirestore.getInstance();
        dref=fb.collection("name").document(number).collection(shopid).document(branch).collection("product").document(name);
        dref.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                oldprice=documentSnapshot.get("price").toString();
                Toast.makeText(getApplicationContext(),"price"+oldprice,Toast.LENGTH_SHORT).show();
                oldStock=documentSnapshot.get("quantity").toString();
                Toast.makeText(getApplicationContext(),"stock"+oldStock,Toast.LENGTH_SHORT).show();
            }
        });



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newprice=et1.getText().toString();
                newstock=et2.getText().toString();
                  if(newprice.equals("")){
            newprice=oldprice;
        }

        if(newstock.equals("")){
            newstock=oldStock;
        }
                dref.update("price",newprice);
                dref.update("quantity",newstock);
                Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(updateproduct.this,Home.class);
                startActivity(intent);
            }
        });


    }
}
