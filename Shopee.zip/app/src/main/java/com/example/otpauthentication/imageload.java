package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.firestore.core.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class imageload extends AppCompatActivity
{
    private  static final String TAG="imageload";
    Button load;
    ImageView imageView;
    public FirebaseStorage storage =FirebaseStorage.getInstance();
    public StorageReference storageReference=storage.getReference();
    public StorageReference first=storageReference.child("images");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imageload);
        final String[] path = new String[1];
        load=findViewById(R.id.btn);
        imageView=findViewById(R.id.img);
        /*try{
        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"check",Toast.LENGTH_SHORT).show();
                first.
            }
        });

    } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error"+e,Toast.LENGTH_SHORT).show();
        }*/


    }
    protected void onStart()
    {
        super.onStart();
        StorageReference query=storageReference.child("images");
       String url="https://console.firebase.google.com/u/1/project/my-application-29d65/storage/my-application-29d65.appspot.com/files~2Fimages";

        Toast.makeText(getApplicationContext(),"check",Toast.LENGTH_SHORT).show();
        Picasso.with(imageload.this).load(url).into(imageView);
        //imageView.setImageURI(Uri.parse("gs://my-application-29d65.appspot.com/images/1583128068923.jpg"));
    }


    }


