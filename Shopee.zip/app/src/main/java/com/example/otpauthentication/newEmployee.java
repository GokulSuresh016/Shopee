package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class newEmployee extends AppCompatActivity {
    EditText name,id,no;
    Button btn;
    ImageView imageView;
    String newname,newid,newno;
    FirebaseFirestore db;
    FirebaseStorage storage;
    StorageReference storageReference;
    public static int i=0;
    private StorageTask mTask;
    public Uri filePath,abpath;
    public static final int IMAGE_PICK_CODE=1000;
    public  static final int PERMISSION_PICK_CODE=1001;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String number,shopid,branch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_employee);
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");

        name=findViewById(R.id.newemptxt1);
        id=findViewById(R.id.newemtxt2);
        no=findViewById(R.id.newemtxt3);
        btn=findViewById(R.id.newempbtn);
        imageView=findViewById(R.id.newempimg);
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newname=name.getText().toString();
                newid=id.getText().toString();
                newno=no.getText().toString();

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        requestPermissions(permission, PERMISSION_PICK_CODE);

                    } else {
                        if (mTask != null && mTask.isInProgress()) {
                            Toast.makeText(getApplicationContext(), "already uploaded file", Toast.LENGTH_SHORT).show();
                        } else {
                            pickImageFromGallary();
                        }
                    }

                } else {
                    if (mTask != null && mTask.isInProgress()) {
                        Toast.makeText(getApplicationContext(), "already uploaded file", Toast.LENGTH_SHORT).show();
                    } else {
                        pickImageFromGallary();
                    }

                }


            }
        });

    }
    private void pickImageFromGallary() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,IMAGE_PICK_CODE);


    }
    public void onRequestPermissionResult(int requestCode,String[] Permission,int[] grandResults)
    {
        switch (requestCode)
        {
            case PERMISSION_PICK_CODE:
            {
                if(grandResults.length>0 && grandResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    pickImageFromGallary();
                }
                else
                {
                    Toast.makeText(this,"permission denied..!",Toast.LENGTH_SHORT).show();
                }

            }

        }
    }
    private String getExtension(Uri uri)
    {
        ContentResolver cr=getContentResolver();
        MimeTypeMap mp=MimeTypeMap.getSingleton();
        return mp.getExtensionFromMimeType(cr.getType(uri));

    }
    protected void onActivityResult(int requestCode, int resultCode,Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE) {
                imageView.setImageURI(data.getData());
                filePath = data.getData();
                Toast.makeText(getApplicationContext(),"uri:"+filePath,Toast.LENGTH_SHORT).show();
                final StorageReference ref = storageReference.child("Images/"+ UUID.randomUUID().toString());
                ref.putFile(filePath)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot) {
                                // Get a URL to the uploaded content
                                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        Toast.makeText(getApplicationContext(), "the url" + uri, Toast.LENGTH_SHORT).show();
                                        abpath = uri;
                                        Toast.makeText(getApplicationContext(),"db check",Toast.LENGTH_SHORT).show();
                                        Map<String,Object> note=new HashMap<>();
                                        note.put("path",abpath.toString());
                                        note.put("name",newname);
                                        note.put("address",newid);
                                        note.put("number",newno);
                                        db.collection("name").document(number).collection(shopid).document(branch).collection("Staff").document(newname).set(note).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Toast.makeText(getApplicationContext(),"successfully updated",Toast.LENGTH_SHORT).show();
                                                Intent intent=new Intent(newEmployee.this,Home.class);
                                                startActivity(intent);
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(getApplicationContext(),"falied",Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                        Map<String,Object> note1=new HashMap<>();
                                        note1.put("number",newno);
                                        db.collection("name").document("phonenumber").set(note1);

                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(getApplicationContext(), "fetching url is failed", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "image pblm", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "exception" + e, Toast.LENGTH_SHORT).show();
        }

    }
}
