package com.example.otpauthentication.ui.gallery;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.otpauthentication.AdapterReport;
import com.example.otpauthentication.R;
import com.example.otpauthentication.adapter;
import com.example.otpauthentication.newEmployee;
import com.example.otpauthentication.profiles;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

public class GalleryFragment extends Fragment implements View.OnClickListener{
    DatabaseReference reference;
    FirebaseFirestore fb;
    CollectionReference cref;
    RecyclerView recyclerView;
    ArrayList<profiles> list;
    adapter adapter1;
    DocumentReference derf;
    profiles pro;
    boolean isMenuopen=false;
    FloatingActionButton fabMain,fabOne,fabTwo;
    Float translationy=100f;
    OvershootInterpolator interpolator=new OvershootInterpolator();
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;



    private GalleryViewModel galleryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        final TextView textView = root.findViewById(R.id.text_gallery);
        galleryViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
                Toast.makeText(getActivity(),"check1",Toast.LENGTH_SHORT).show();
            }
        });
        sharedPreferences=this.getActivity().getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        String number,shopid,branch;
        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");
        Toast.makeText(getContext(),"is"+branch,Toast.LENGTH_SHORT).show();



        recyclerView= root.findViewById(R.id.recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        list=new ArrayList<>();


      try {
          fb=FirebaseFirestore.getInstance();
          cref=fb.collection("name").document(number).collection(shopid).document(branch).collection("Staff");
          cref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
              @Override
              public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                  for(QueryDocumentSnapshot documentSnapshot:queryDocumentSnapshots){
                      pro=documentSnapshot.toObject(profiles.class);
                      list.add(pro);
                  }
                  adapter1 = new adapter(GalleryFragment.this,list);
                  recyclerView.setAdapter(adapter1);
                  recyclerView.setHasFixedSize(true);

              }
          }).addOnFailureListener(new OnFailureListener() {
              @Override
              public void onFailure(@NonNull Exception e) {
                  Toast.makeText(getContext(),"failure",Toast.LENGTH_SHORT).show();
              }
          });



      } catch (Exception e) {
          e.printStackTrace();
      }
        try {
            fabMain = root.findViewById(R.id.fab);




            fabMain.setOnClickListener((View.OnClickListener) this);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getActivity(),"exception"+e,Toast.LENGTH_SHORT).show();
        }

        return root;
    }


        public void onClick (View view)
        {

                    Intent intent=new Intent(getActivity(),newEmployee.class);
                    startActivity(intent);
                    Toast.makeText(getActivity(), "fabMain", Toast.LENGTH_SHORT).show();
        }






}