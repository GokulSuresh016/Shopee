package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class ReportShow extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    FirebaseFirestore fb;
    DocumentReference db;
    TextView txt1,txt2,txt3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_show);
        fb=FirebaseFirestore.getInstance();
        txt1=findViewById(R.id.ReportShoetx1);
        txt2=findViewById(R.id.ReportShoetx2);
        txt3=findViewById(R.id.ReportShoetx3);


        Intent i=getIntent();
        String doc=i.getStringExtra("document");
        Toast.makeText(getApplicationContext(),"doc"+doc,Toast.LENGTH_SHORT).show();
        try {
        sharedPreferences=getSharedPreferences("varifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();

            String ye = sharedPreferences.getString("year", "null");
            int mm = sharedPreferences.getInt("month", 0);
            if(mm<=9){
              mm='0'+mm;
            }
            Toast.makeText(getApplicationContext(), "year" + ye + mm, Toast.LENGTH_SHORT).show();
           db = fb.collection("Report").document(ye).collection(String.valueOf(mm)).document(doc);
            db.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot documentSnapshot = task.getResult();
                        if (documentSnapshot != null) {
                            String product = documentSnapshot.get("Product").toString();
                            txt1.setText(product);
                            String amount = documentSnapshot.get("Amount").toString();
                            txt2.setText(amount);
                            String Quantity = documentSnapshot.get("Quantity").toString();
                            txt3.setText(Quantity);

                        }
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error"+e, Toast.LENGTH_SHORT).show();
        }

    }
}
