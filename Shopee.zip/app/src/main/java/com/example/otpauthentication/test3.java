package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;

import java.util.ArrayList;
import java.util.Collection;

public class test3 extends AppCompatActivity {

    DatabaseReference reference;
    RecyclerView recyclerView;
    ArrayList<profiles> list;
    adapter adapter1;
    profiles pro;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test3);
        pro=new profiles();
        Toast.makeText(getApplicationContext(),"check1",Toast.LENGTH_SHORT).show();
        recyclerView=(RecyclerView) findViewById(R.id.recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<profiles>();
        FloatingActionButton floatingActionButton=findViewById(R.id.action_button);

        Toast.makeText(getApplicationContext(),"check2",Toast.LENGTH_SHORT).show();
        try {
            reference = FirebaseDatabase.getInstance().getReference().child("profiles");

            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        profiles p = dataSnapshot1.getValue(profiles.class);
                        list.add(p);

                    }
                   // adapter1 = new adapter(this, list);
                    recyclerView.setAdapter(adapter1);

                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error"+e,Toast.LENGTH_SHORT).show();
        }
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name="ammu";
                String address="hjgj";
                /*pro.setName(name);
                pro.setAddress(address);
                reference.child(name).setValue(pro);
                startActivity(new Intent(getApplicationContext(), test3.class));
                Toast.makeText(getApplicationContext(),"floating button",Toast.LENGTH_SHORT).show();*/
                DatabaseReference dref=FirebaseDatabase.getInstance().getReference("profiles").child(name);
                dref.removeValue();
            }
        });

    }
}
