package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Instructions extends AppCompatActivity {
    Spinner spinner1;
    Spinner spinner2;
    EditText editText;
    Button button;
    String item,to;
    FirebaseFirestore db;
    CollectionReference cref;
    CollectionReference cref1;
    ArrayAdapter<String> adapter, adapter1;
    ArrayList<String> list,division,list2;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);
        spinner1 = findViewById(R.id.InsSpinner1);
        spinner2 = findViewById(R.id.InsSpinner2);
        editText = findViewById(R.id.InsEditText1);
        button = findViewById(R.id.InsButton1);
        final String number,shopid,branch;
        db = FirebaseFirestore.getInstance();
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");
        cref = db.collection("name").document(number).collection(shopid);

        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        final String time=sdf.format(new Date());


        list = new ArrayList<>();
        division=new ArrayList<>();
        list2 = new ArrayList<>();


        spinner1.setAdapter(adapter);
        spinner2.setAdapter(adapter1);
        cref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                  String data=documentSnapshot.getId();
                    list.add(data);
                    division.add(data);

                }
                adapter = new ArrayAdapter<>(Instructions.this, android.R.layout.simple_spinner_dropdown_item, list);
                spinner1.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        });
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                item=parent.getItemAtPosition(position).toString();
                cref1=cref.document(item).collection("Staff");
                cref1.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            String emp = documentSnapshot.getId();
                            list2.add(emp);
                        }
                        adapter1 = new ArrayAdapter<>(Instructions.this, android.R.layout.simple_spinner_dropdown_item, list2);
                        spinner2.setAdapter(adapter1);
                    }
                });
                list2.clear();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                to =parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"to"+to,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(),"nothing selected",Toast.LENGTH_SHORT).show();

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                String message=editText.getText().toString();
                Map<String,Object> note=new HashMap<>();
                note.put("what",message);
                note.put("when",time);
                note.put("who","admin");
                db.collection("name").document(number).collection(shopid).document(item).collection("Staff").document(to).collection("meassage").document(time).set(note).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(getApplicationContext(),"updated successfully"+to,Toast.LENGTH_SHORT).show();
                        Intent i=new Intent(Instructions.this,Home.class);
                        startActivity(i);
                    }
                });
            }
        });
    }
}


