package com.example.otpauthentication;

public class inboxgetdata {
    public inboxgetdata() {
    }
    public inboxgetdata(String message,String text){
        this.message=message;


    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    String message;

}
