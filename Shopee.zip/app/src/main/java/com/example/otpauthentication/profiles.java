package com.example.otpauthentication;

public class profiles {
    private String name;
    private String address;
    private String path;
  private String number;
    public profiles(String name, String address,String path,String number) {
        this.name = name;
        this.address = address;
        this.path=path;
        this.number=number;
    }

    public profiles() {

    }
    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }




}
