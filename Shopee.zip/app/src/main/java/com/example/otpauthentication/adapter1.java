package com.example.otpauthentication;

        import android.content.Context;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ImageView;
        import android.widget.TextView;

        import androidx.annotation.NonNull;
        import androidx.recyclerview.widget.RecyclerView;
        import androidx.recyclerview.widget.RecyclerView.ViewHolder;

        import com.example.otpauthentication.ui.slideshow.SlideshowFragment;
        import com.squareup.picasso.Picasso;

        import java.util.ArrayList;

public class adapter1 extends RecyclerView.Adapter<adapter1.viewholder> {

    SlideshowFragment context;
    ArrayList<profiles> profiles;

    public adapter1(SlideshowFragment c, ArrayList<profiles> p)
    {
        context=c;
        profiles=p;
    }


    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {

        holder.name.setText(profiles.get(position).getName());
        holder.address.setText(profiles.get(position).getAddress());
        Picasso.with(context.getContext()).load(profiles.get(position).getPath()).into(holder.profilepic);

    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    class viewholder extends RecyclerView.ViewHolder{

        TextView name,address;
        ImageView profilepic;

        public viewholder(@NonNull View itemView) {
            super(itemView);

            name=(TextView)itemView.findViewById(R.id.name);
            address=(TextView)itemView.findViewById(R.id.address);
            profilepic=(ImageView) itemView.findViewById(R.id.img_v);
        }
    }
}

