package com.example.otpauthentication;

public class productClass {
    String name;
    String price;
    String quantity;
    String path;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }



    public productClass() {

    }

    public productClass(String name, String price, String quantity, String path) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.path = path;
    }



}
