package com.example.otpauthentication;

public class notificationload {
    private String who;
    private String when;
    private String what;


    public notificationload(String who, String when, String what) {
        this.who = who;
        this.when = when;
        this.what = what;
    }

    public notificationload() {


    }

    public String getWho() {
        return who;
    }

    public void setWho(String who) {
        this.who = who;
    }

    public String getWhen() {
        return when;
    }

    public void setWhen(String when) {
        this.when = when;
    }

    public String getWhat() {
        return what;
    }

    public void setWhat(String what) {
        this.what = what;
    }
}
