package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageRegistrar;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.StreamDownloadTask;
import com.google.firebase.storage.UploadTask;
import com.google.firestore.v1.StructuredQuery;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class imagetest extends AppCompatActivity {
    ImageView mImageview;
    ImageView nImageView;
    Button displayBtn;
    Button mChoosebtn;
    Button data;
    FirebaseFirestore db;
    FirebaseStorage storage;
    StorageReference storageReference;
    private StorageTask mTask;
    public Uri filePath,abpath;
    public static final int IMAGE_PICK_CODE=1000;
   public  static final int PERMISSION_PICK_CODE=1001;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imagetest);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference("images");
        mImageview=findViewById(R.id.image_view);
        data=findViewById(R.id.db);
        db=FirebaseFirestore.getInstance();
        mChoosebtn=findViewById(R.id.choose_image_btn);
        displayBtn=findViewById(R.id.display_img);
        nImageView=findViewById(R.id.image_view2);
        data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map <String, Object> note = new HashMap<>();
                note.put("path","hai");
                db.collection("name").document("+919526831980").set(note);
            }
        });
    try {

            displayBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "checkmm", Toast.LENGTH_SHORT).show();
                    String url = "https://firebasestorage.googleapis.com/v0/b/my-application-29d65.appspot.com/o/images%2F1583128068923.jpg?alt=media&token=e8c1f45b-de8f-48b6-8fdc-582991b12032";
                  // Bitmap bmp;
                   //bmp=BitmapFactory.decodeStream(url);
                    Toast.makeText(getApplicationContext(), "check152", Toast.LENGTH_SHORT).show();
                    Picasso.with(getApplicationContext()).load(abpath).into(nImageView);
                    //nImageView.setImageBitmap(bmp);
                    Toast.makeText(getApplicationContext(), "check1552"+url, Toast.LENGTH_SHORT).show();
                   /* storageReference.child("images/gs://my-application-29d65.appspot.com/images/1583128068923.jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {

                            Uri downloadUri =

                        }
                    });*/

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error"+e,Toast.LENGTH_SHORT).show();
        }

        mChoosebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        requestPermissions(permission, PERMISSION_PICK_CODE);

                    } else {
                        if (mTask != null && mTask.isInProgress()) {
                            Toast.makeText(getApplicationContext(), "already uploaded file", Toast.LENGTH_SHORT).show();
                        } else {
                            pickImageFromGallary();
                        }
                    }

                }
                    else
                    {
                        if (mTask!=null && mTask.isInProgress()) {
                            Toast.makeText(getApplicationContext(),"already uploaded file",Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            pickImageFromGallary();
                        }

                }

            }
        });


    }

    private void pickImageFromGallary() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,IMAGE_PICK_CODE);


    }

    public void onRequestPermissionResult(int requestCode,String[] Permission,int[] grandResults)
    {
        switch (requestCode)
        {
            case PERMISSION_PICK_CODE:
            {
                if(grandResults.length>0 && grandResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    pickImageFromGallary();
                }
                else
                {
                    Toast.makeText(this,"permission denied..!",Toast.LENGTH_SHORT).show();
                }

             }

        }
    }
private String getExtension(Uri uri)
{
    ContentResolver cr=getContentResolver();
    MimeTypeMap mp=MimeTypeMap.getSingleton();
    return mp.getExtensionFromMimeType(cr.getType(uri));

}
    protected void onActivityResult(int requestCode, int resultCode,Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE) {
                mImageview.setImageURI(data.getData());
                filePath = data.getData();
               // Toast.makeText(getApplicationContext(),"uri:"+filePath,Toast.LENGTH_SHORT).show();
                 final StorageReference ref=storageReference.child(System.currentTimeMillis()+"."+getExtension(filePath));
               mTask=ref.putFile(filePath)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot) {
                                // Get a URL to the uploaded content
                                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        Toast.makeText(getApplicationContext(),"the url"+uri,Toast.LENGTH_SHORT).show();
                                        abpath=uri;
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(getApplicationContext(),"feching url is failed",Toast.LENGTH_SHORT).show();
                                    }
                                });

                                    //String downloaduri = taskSnapshot.getStorage().getPath();
                                   /* Task<Uri> path=storageReference.child("images/1583328904186.jpg").getDownloadUrl();
                                    //Map<String, Object> note = new HashMap<>();
                                   // note.put("path",downloaduri);
                                    //note.put("url",path);
                                    Toast.makeText(getApplicationContext(),"check3",Toast.LENGTH_SHORT).show();
                                    db.collection("name").document("+919526831980").set(note).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Toast.makeText(getApplicationContext(),"query",Toast.LENGTH_SHORT).show();
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(getApplicationContext(),"n q",Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                    Picasso.with(getApplicationContext()).load(String.valueOf(path)).into(nImageView);
                                    Toast.makeText(getApplicationContext(),"actualpath="+path,Toast.LENGTH_SHORT).show();
                                    Toast.makeText(getApplicationContext(),"path="+downloaduri,Toast.LENGTH_SHORT).show();*/

                                }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                                // ...
                                Toast.makeText(getApplicationContext(),"failure",Toast.LENGTH_SHORT).show();
                            }
                        });



               /* StorageReference ref = storageReference.child("images/"+ UUID.randomUUID().toString());
                ref.putFile(filePath)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();
                            }

                            })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(),"failure",Toast.LENGTH_SHORT).show();
                            }
                        });*/

            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),"exception"+e,Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }


                   //StorageReference sref=storage.getReferenceFromUrl("gs://my-application-29d65.appspot.com/images/1582959452442.jpg");
                    //StorageReference ref=storage.getReferenceFromUrl("gs://my-application-29d65.appspot.com/images");

                    /*ref.getFile(new File("gs://my-application-29d65.appspot.com/images/1582959452442.jpg")).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            Bitmap bitmap=BitmapFactory.decodeFile(String.valueOf(filePath));
                            nImageView.setImageBitmap(bitmap);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(),"failure",Toast.LENGTH_SHORT).show();
                        }
                    });*/


    }


}
