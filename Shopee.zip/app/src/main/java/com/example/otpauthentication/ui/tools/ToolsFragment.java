package com.example.otpauthentication.ui.tools;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.otpauthentication.R;
import com.example.otpauthentication.ReportView;
import com.example.otpauthentication.datePicker;

import java.util.Calendar;

public class ToolsFragment extends Fragment {
    TextView tv;
    Button btn;
    Calendar calendar;
    Integer day,month,year;
    String day1,month1,year1;
    public  static String  day2,month2,year2;

    private ToolsViewModel toolsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        toolsViewModel =
                ViewModelProviders.of(this).get(ToolsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_tools, container, false);
        final TextView textView = root.findViewById(R.id.text_tools);
        toolsViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        calendar = Calendar.getInstance();
        day = calendar.get(Calendar.DAY_OF_MONTH);
        month = calendar.get(Calendar.MONTH);
        year = calendar.get(Calendar.YEAR);
        month = month + 1;
        Toast.makeText(getActivity(),"intools",Toast.LENGTH_SHORT).show();
        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                year2=""+year;
                month2=""+month;
                day2=""+dayOfMonth;
                Intent i = new Intent(getContext(), ReportView.class);
                startActivity(i);
            }
        }, year, month, day);
        datePickerDialog.show();


       /* Intent intent=new Intent(getActivity(), datePicker.class);
        startActivity(intent);*/
        return root;
    }

}