package com.example.otpauthentication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter2 extends RecyclerView.Adapter<Adapter2.myViewHolder> {

    Context context;
    ArrayList<notificationload> notificationloads;

    public Adapter2(Context c,ArrayList<notificationload> p){
        context=c;
        notificationloads=p;
    }
    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return  new myViewHolder(LayoutInflater.from(context).inflate(R.layout.notification1,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        holder.txt3.setText(notificationloads.get(position).getWho());
        holder.txt2.setText(notificationloads.get(position).getWhen());
        holder.txt1.setText(notificationloads.get(position).getWhat());

    }

    @Override
    public int getItemCount() {
        return notificationloads.size();
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView txt1;
        TextView txt2;
        TextView txt3;
        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            txt1=itemView.findViewById(R.id.nText1);
            txt2=itemView.findViewById(R.id.nText2);
            txt3=itemView.findViewById(R.id.nText3);


        }
    }
}
