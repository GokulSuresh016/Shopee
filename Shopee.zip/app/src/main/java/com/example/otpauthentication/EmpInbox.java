package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import static android.R.layout.simple_spinner_dropdown_item;

public class EmpInbox extends AppCompatActivity  {
    FirebaseFirestore db;
    CollectionReference cref;
    RecyclerView recyclerView;
    ArrayList<notificationload> list;
    RecyclerView.LayoutManager layoutManager;
    Adapter2 adapter;   SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String number,shopid,branch,id;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_inbox);
        recyclerView = findViewById(R.id.EmpInboxRecycle);
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");
        id=sharedPreferences.getString("id","");
       db= FirebaseFirestore.getInstance();
        list=new ArrayList<>();
        db=FirebaseFirestore.getInstance();
        cref=db.collection("name").document("+919526831980").collection("mshop").document("erk").collection("Staff").document("amal").collection("meassage");
        cref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(queryDocumentSnapshots.isEmpty()){
                    Toast.makeText(getApplicationContext(),"document empty",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    for(DocumentSnapshot documentSnapshot:queryDocumentSnapshots) {
                        notificationload nload = documentSnapshot.toObject(notificationload.class);
                        list.add(nload);
                    }
                    adapter=new Adapter2(EmpInbox.this,list);
                    recyclerView.setAdapter(adapter);
                }


            }

        });
    }

}

