package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class updateBranch extends AppCompatActivity {
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_branch);
        final String id=getIntent().getExtras().getString("shopid");
        final int no=getIntent().getExtras().getInt("number");
        btn=findViewById(R.id.update);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(updateBranch.this,AddBranch.class);
                i.putExtra("number",no);
                i.putExtra("shopid",id);
                startActivity(i);
                finish();
            }
        });


    }
}
