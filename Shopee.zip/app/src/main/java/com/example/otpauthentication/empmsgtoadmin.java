package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class empmsgtoadmin extends AppCompatActivity {
    EditText msg;
    Button btn;
    String message;
    FirebaseFirestore fb;
    CollectionReference cref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empmsgtoadmin);
        msg=findViewById(R.id.toadminext);
        btn=findViewById(R.id.toadminbtn);
        fb=FirebaseFirestore.getInstance();
        cref=fb.collection("name").document("+919526831980").collection("mshop").document("erk").collection("meassage");
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        final String currenttime=sdf.format(new Date());
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                message=msg.getText().toString();
                Map<String,Object> note=new HashMap<>();
                note.put("who","emp1");
                note.put("when",currenttime);
                note.put("what",message);
                cref.document("emp1").set(note).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });


    }
}
