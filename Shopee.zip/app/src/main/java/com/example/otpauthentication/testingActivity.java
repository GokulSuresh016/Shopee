package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class testingActivity extends AppCompatActivity {
    private FirebaseFirestore firebaseFirestore;
    DatabaseReference fb;

    Button btnAdd;
    EditText etText;
    ListView listView;

    private ArrayList<String>arrayList=new ArrayList<>();
    private ArrayAdapter<String>arrayAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing);
        btnAdd=findViewById(R.id.btn_test);
        etText=findViewById(R.id.edit_Text);
        listView=findViewById(R.id.list_View);


        fb=FirebaseDatabase.getInstance().getReference("name");
        arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);
        Toast.makeText(getApplicationContext(),"check1",Toast.LENGTH_SHORT).show();

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fb.push().setValue(etText.getText().toString());
                Toast.makeText(getApplicationContext(),"check2",Toast.LENGTH_SHORT).show();
            }
        });

        fb.addChildEventListener(
                new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        String string=dataSnapshot.getValue(String.class);
                        arrayList.add(string);
                        arrayAdapter.notifyDataSetChanged();

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                }
        );


    }
}
