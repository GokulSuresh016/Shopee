package com.example.otpauthentication;

public class reportgetter {
    String Amount,Product,Quantity,Time;

    public reportgetter(String Amount, String Product, String Quantity, String Time) {
       this.Amount = Amount;
        this.Product = Product;
        this.Quantity = Quantity;
        this.Time = Time;
    }

    public reportgetter() {
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String Amount) {
        Amount =Amount;
    }

    public String getProduct() {
        return Product;
    }

    public void setProduct(String Product) {
        Product = Product;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String Quantity) {
        Quantity = Quantity;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String Time) {
        Time = Time;
    }
}
