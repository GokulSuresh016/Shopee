package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.example.otpauthentication.ui.home.HomeFragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Flash_displ extends AppCompatActivity {


    static String number;
    FirebaseFirestore f;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flash_displ);
        f= FirebaseFirestore.getInstance();
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        check();
       // startActivity(new Intent(getApplicationContext(), MainActivity.class));
        //finish();
    }

    void check() {
        boolean b = sharedPreferences.getBoolean("login", true);
        try{
        if (b == true) {

            String nm = sharedPreferences.getString("phonenumber", null);

            DocumentReference df = f.collection("name").document(nm);
            df.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot documentSnapshot) {
                    if (documentSnapshot.exists()) {
                        Toast.makeText(getApplicationContext(), "user successfully signed in", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), Home.class));
                        finish();
                    } else {
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        finish();
                    }
                }
            });


        } else {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }
    }
        catch(NullPointerException e) {
            Toast.makeText(this, "ERROR:  " + e, Toast.LENGTH_LONG).show();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();

        }
    }

}
