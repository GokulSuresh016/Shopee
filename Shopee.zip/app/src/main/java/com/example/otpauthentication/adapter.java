package com.example.otpauthentication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.otpauthentication.ui.gallery.GalleryFragment;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;


import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

public class adapter extends RecyclerView.Adapter<adapter.view> {
    GalleryFragment context;
    ArrayList<profiles> list;
    FirebaseFirestore fb;
    DocumentReference dref;

    public adapter(GalleryFragment context, ArrayList<profiles> p)
    {
        this.context = context;
         list=p;

    }


    @NonNull
    @Override
    public view onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final view view;
        view = new view(LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview, parent, false));
        return view;
    }

    @Override
    public void onBindViewHolder(@NonNull final view holder, final int position) {

        fb=FirebaseFirestore.getInstance();

        holder.name.setText(list.get(position).getName());
        holder.address.setText(list.get(position).getAddress());
        holder.number.setText(list.get(position).getNumber());
        Picasso.with(context.getContext()).load(list.get(position).getPath()).into(holder.img);
        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dref=fb.collection("name").document(holder.number1).collection(holder.shopid).document(holder.branch).collection("Staff").document(list.get(position).getName());
                dref.delete();
                Toast.makeText(v.getContext(),"deleted",Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class view extends RecyclerView.ViewHolder
    {

        TextView name,address,number;
        ImageView img;
        Button btn;
        SharedPreferences sharedPreferences;
        SharedPreferences.Editor editor;
        String number1,shopid,branch;



public view(View view)
{
    super(view);
    name=(TextView)itemView.findViewById(R.id.name);
    address=(TextView)itemView.findViewById(R.id.address);
    img=(ImageView)itemView.findViewById(R.id.img_v);
    btn=(Button)view.findViewById(R.id.card_btn);
    number=(TextView)view.findViewById(R.id.number);
    sharedPreferences=view.getContext().getSharedPreferences("verifyacc",MODE_PRIVATE);
    editor=sharedPreferences.edit();
    number1=sharedPreferences.getString("phonenumber","");
    shopid=sharedPreferences.getString("shopid","");
    branch=sharedPreferences.getString("branch","");




}
    }


}
