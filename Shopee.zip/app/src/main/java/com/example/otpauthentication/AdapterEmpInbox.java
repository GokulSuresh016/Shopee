package com.example.otpauthentication;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;



import java.util.ArrayList;

public class AdapterEmpInbox extends RecyclerView.Adapter<AdapterEmpInbox.inboxHolder> {
    ArrayList<String> list;



    public AdapterEmpInbox(ArrayList<String> list){
        super();
        this.list=list;

    }



    @NonNull
    @Override
    public inboxHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.inboxcard,parent,false);
        return new inboxHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull inboxHolder holder, final int position) {
        holder.message.setText(list.get(position));
        holder.relative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg;
                msg=list.get(position);
                Toast.makeText(v.getContext(),msg,Toast.LENGTH_SHORT).show();
                Intent i=new Intent(v.getContext(),EmpMsgShow.class);
                i.putExtra("message",msg);
                v.getContext().startActivity(i);

            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class inboxHolder extends RecyclerView.ViewHolder {
        TextView message;
        Button btn;
        RelativeLayout relative;


        public inboxHolder(@NonNull final View itemView) {
            super(itemView);
            message = itemView.findViewById(R.id.inboxText);
          /*  btn = itemView.findViewById(R.id.btncard);
            relative=itemView.findViewById(R.id.relative);*/

        }
    }
}
