package com.example.otpauthentication.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.otpauthentication.AddBranch;
import com.example.otpauthentication.Alert;
import com.example.otpauthentication.Instructions;
import com.example.otpauthentication.R;
import com.example.otpauthentication.adapter;
import com.example.otpauthentication.notification;
import com.example.otpauthentication.profiles;
import com.example.otpauthentication.test3;
import com.example.otpauthentication.updateBranch;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    CardView cardView,cardView1,cardView2,cardView3;

    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);



            }
        });
       cardView=root.findViewById(R.id.card);
       cardView1=root.findViewById(R.id.card1);
        cardView2=root.findViewById(R.id.card2);
        cardView3=root.findViewById(R.id.card3);
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int no=1;
                String id="mshop";
                Intent i=new Intent(getActivity(), AddBranch.class);
                i.putExtra("number",no);
                i.putExtra("shopid",id);
                startActivity(i);
            }
        });

                cardView1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent inten=new Intent(getActivity(), Alert.class);
                        startActivity(inten);
                    }
                });
        cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), Instructions.class);
                startActivity(intent);
            }
        });

        cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), notification.class);
                startActivity(i);
            }
        });






        return root;



    }

}