package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Alert extends AppCompatActivity {
    Spinner spinner;
    ArrayAdapter<String> adapter;
    ArrayList<String> list;
    FirebaseFirestore db;
   DocumentReference dref;
   DatabaseReference database1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert);
        try {
            spinner = findViewById(R.id.alertSpinner);
            db=FirebaseFirestore.getInstance();


            database1=  FirebaseDatabase.getInstance().getReference("country");

            list=new ArrayList<>();

            adapter=new ArrayAdapter<>(Alert.this,android.R.layout.simple_spinner_dropdown_item,list);
            Toast.makeText(getApplicationContext(),"check1",Toast.LENGTH_SHORT).show();
            spinner.setAdapter(adapter);

             db.collection("name").document("phonenumber").get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                 @Override
                 public void onSuccess(DocumentSnapshot documentSnapshot) {

                         list.add(documentSnapshot.getString("id1"));
                         list.add(documentSnapshot.getString("id2"));

adapter.notifyDataSetChanged();
                 }

             });


        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error"+e,Toast.LENGTH_SHORT).show();
        }
    }
}
