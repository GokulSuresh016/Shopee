package com.example.otpauthentication;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.otpauthentication.ui.slideshow.SlideshowFragment;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterProduct extends RecyclerView.Adapter<AdapterProduct.viewholder> {
    SlideshowFragment context;
    ArrayList<productClass> profile;

    public AdapterProduct(SlideshowFragment c, ArrayList<productClass> p){
context=c;
profile=p;
    }




    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.caedviewproduct,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, final int position) {
        holder.name.setText(profile.get(position).getName());
        holder.rate.setText(profile.get(position).getPrice());
        holder.remaining.setText(profile.get(position).getQuantity());
        Picasso.with(context.getContext()).load(profile.get(position).getPath()).into(holder.imageView);
        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String name;
            name=profile.get(position).getName();
                Intent intent=new Intent(v.getContext(),productView.class);
                intent.putExtra("document",name);
                v.getContext().startActivity(intent);
            }
        });

        holder.btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name;
                name=profile.get(position).getName();
             Intent intent=new Intent(v.getContext(),updateproduct.class);
                intent.putExtra("document",name);
             v.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return profile.size();
    }

    public  class viewholder extends RecyclerView.ViewHolder{

        TextView name,rate,remaining;
        ImageView imageView;
        Button btn,btn1;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            name=(TextView)itemView.findViewById(R.id.name);
            rate=(TextView)itemView.findViewById(R.id.address);
            remaining=(TextView)itemView.findViewById(R.id.number);
            imageView=(ImageView) itemView.findViewById(R.id.img_v);
            btn=(Button)itemView.findViewById(R.id.card_btn);
            btn1=(Button)itemView.findViewById(R.id.card_btn1);
        }
    }
}