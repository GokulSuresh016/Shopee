package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Empsolidreport extends AppCompatActivity {
EditText editText;
Spinner spinner1;
TextView textView;
String textView1,textView2,textView3;
Button save;
FirebaseFirestore db;
CollectionReference ref;
ArrayList<String> list;
ArrayAdapter<String> arrayAdapter;
String product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empsolidreport);
        editText=findViewById(R.id.ReportEdt2);
        textView=findViewById(R.id.ReportEdt3);
        spinner1=findViewById(R.id.Reportsp1);
        save=findViewById(R.id.Reportbtn);
        db=FirebaseFirestore.getInstance();
        list=new ArrayList<>();

        ref=db.collection("name").document("+919526831980").collection("mshop").document("erk").collection("product");
        ref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for(QueryDocumentSnapshot documentSnapshot:queryDocumentSnapshots){
                    list.add(documentSnapshot.getId());
                }
                arrayAdapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_item,list);
                spinner1.setAdapter(arrayAdapter);
            }
        });
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                 product=list.get(position);
                DocumentReference dref=ref.document(product);
                dref.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        textView.setText(documentSnapshot.get("price").toString());
                        editText.setText(documentSnapshot.get("quantity").toString());
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String quantity;
                quantity=editText.getText().toString();
             DocumentReference dref=ref.document(product);
             dref.update("quantity",quantity);
            }
        });



    }
}
