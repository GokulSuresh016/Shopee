package com.example.otpauthentication;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class AdapterReport extends RecyclerView.Adapter<AdapterReport.ViewHolder> {
    ArrayList<reportgetter> list;

    public AdapterReport(ArrayList<reportgetter> list)
    {
        this.list=list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.inboxcard,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.txt1.setText(list.get(position).getProduct());
        holder.txt2.setText(list.get(position).getQuantity());
        holder.txt3.setText(list.get(position).getAmount());
        holder.txt4.setText(list.get(position).getTime());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        TextView txt1,txt2,txt3,txt4;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt1=itemView.findViewById(R.id.inboxText);
            txt2=itemView.findViewById(R.id.inboxText1);
            txt3=itemView.findViewById(R.id.inboxText2);
            txt4=itemView.findViewById(R.id.inboxText3);
        }
    }

}
