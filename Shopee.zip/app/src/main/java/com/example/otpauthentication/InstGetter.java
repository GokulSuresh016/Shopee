package com.example.otpauthentication;

public class InstGetter {
    private String data;
public InstGetter(){

}
    public InstGetter(String data){
        this.data=data;

    }
public String getData()
{
    return data;
}
}
