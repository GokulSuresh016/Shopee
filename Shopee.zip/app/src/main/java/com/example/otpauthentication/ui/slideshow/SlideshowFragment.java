package com.example.otpauthentication.ui.slideshow;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.otpauthentication.AdapterProduct;
import com.example.otpauthentication.R;
import com.example.otpauthentication.adapter;
import com.example.otpauthentication.adapter1;
import com.example.otpauthentication.datePicker;
import com.example.otpauthentication.newEmployee;
import com.example.otpauthentication.newproduct;
import com.example.otpauthentication.productClass;
import com.example.otpauthentication.profiles;
import com.example.otpauthentication.ui.gallery.GalleryFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

public class SlideshowFragment extends Fragment {
    DatabaseReference ref;
    FirebaseFirestore fb;
    CollectionReference cref;
    AdapterProduct adapterProduct;
    RecyclerView rw;
ArrayList<productClass> list;
productClass pro;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    FloatingActionButton fabMain;


    private SlideshowViewModel slideshowViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                ViewModelProviders.of(this).get(SlideshowViewModel.class);
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);
        final TextView textView = root.findViewById(R.id.text_slideshow);
        slideshowViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        fabMain=root.findViewById(R.id.fabslideshow);
        sharedPreferences=this.getActivity().getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        String number,shopid,branch;
        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");
        fb=FirebaseFirestore.getInstance();
        rw=root.findViewById(R.id.recycle1);
        rw.setLayoutManager(new LinearLayoutManager(getActivity()));
        list=new ArrayList<>();
        try{
          cref=fb.collection("name").document(number).collection(shopid).document(branch).collection("product");
          cref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
              @Override
              public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                  for(QueryDocumentSnapshot queryDocumentSnapshot:queryDocumentSnapshots){
                    pro=queryDocumentSnapshot.toObject(productClass.class);
                    list.add(pro);
                  }
                  adapterProduct=new AdapterProduct(SlideshowFragment.this,list);
                  rw.setAdapter(adapterProduct);
                  rw.setHasFixedSize(true);

              }
          }).addOnFailureListener(new OnFailureListener() {
              @Override
              public void onFailure(@NonNull Exception e) {
                  Toast.makeText(getContext(),"error"+e,Toast.LENGTH_SHORT).show();
              }
          });

          fabMain.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Intent intent=new Intent(getActivity(), newproduct.class);
                  startActivity(intent);
              }
          });


        }catch (Exception e){
            Toast.makeText(getContext(),"error"+e,Toast.LENGTH_SHORT).show();
        }



        return root;
    }

}