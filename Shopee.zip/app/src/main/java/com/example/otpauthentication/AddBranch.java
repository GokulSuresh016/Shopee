package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AddBranch extends AppCompatActivity {
    private String B_code;
    private String Details;
    private static int no,count=0;
    private String shopid;
    EditText name1;
    EditText address1;
    Button submit;
    FirebaseFirestore db;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_branch);
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        final String number=sharedPreferences.getString("phonenumber","");

        name1=findViewById(R.id.b_Name);
        address1=findViewById(R.id.b_Address);
        submit=findViewById(R.id.Submit);
        B_code=name1.getText().toString();
        db=FirebaseFirestore.getInstance();
        Details=address1.getText().toString();
        Toast.makeText(getApplicationContext(),"check1",Toast.LENGTH_SHORT).show();
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
Toast.makeText(getApplicationContext(),"check2",Toast.LENGTH_SHORT).show();
                    no=getIntent().getExtras().getInt("number");
                    shopid=getIntent().getExtras().getString("shopid");
                    Toast.makeText(getApplicationContext(),"check3"+no,Toast.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(),"check4"+shopid,Toast.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(),"check5"+count,Toast.LENGTH_SHORT).show();
                    if(no>count) {

                        Map<String, String> note = new HashMap<>();
                        note.put("Code", name1.getText().toString());
                        note.put("location", address1.getText().toString());
                        db.collection("name").document(number).collection(shopid).document(name1.getText().toString()).set(note).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(),"failed",Toast.LENGTH_SHORT).show();
                            }
                        }).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(getApplicationContext(), "Successfully created", Toast.LENGTH_SHORT).show();
                                name1.setText("");
                                address1.setText("");
                                count = count + 1;
                            }
                        });


                    }
                    else
                    {
                        Intent i=new Intent(AddBranch.this,Home.class);
                        startActivity(i);
                    }
                   /*.addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(getApplicationContext(),"Successfull",Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(),"failed",Toast.LENGTH_SHORT).show();
                        }
                    });*/
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),"exception"+e,Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
