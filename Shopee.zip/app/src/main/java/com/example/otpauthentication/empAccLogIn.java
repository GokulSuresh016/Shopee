package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class empAccLogIn extends AppCompatActivity {
    EditText editText,editText1,editText2,editText3;
    Button btn;
    FirebaseFirestore fb;
    String shcode,no,brch,id;
    DocumentReference dref,dref1;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_acc_log_in);
        editText = findViewById(R.id.emploginEdit1);
        editText1 = findViewById(R.id.emploginEdit2);
        editText2=findViewById(R.id.emploginEdit3);
        editText3=findViewById(R.id.emploginEdit4);
        sharedPreferences = getSharedPreferences("varifyacc", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        fb = FirebaseFirestore.getInstance();
        btn=findViewById(R.id.emploginbtn);
        try {

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    shcode = editText.getText().toString();
                    no = editText1.getText().toString();
                    brch = editText2.getText().toString();
                    id = editText3.getText().toString();
                    dref = fb.collection("name").document(no).collection(shcode).document(brch).collection("Staff").document(id);
                    dref.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {
                                editor.putBoolean("login", true);
                                editor.putString("id", id);
                                editor.putString("branch", brch);
                                editor.putString("shop", shcode);
                                editor.putString("type","employee");
                                editor.commit();
                                startActivity(new Intent(getApplicationContext(), employeehome.class));
                            } else {
                                Toast.makeText(getApplicationContext(), "no not exist", Toast.LENGTH_SHORT).show();

                            }

                        }
                    });

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "error" + e, Toast.LENGTH_SHORT).show();
        }
    }

    }
