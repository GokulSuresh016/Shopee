package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
      FirebaseAuth auth;
      Button sent,check;
      EditText num,otp;
      String otpcode;
  static String number;
FirebaseFirestore f;
SharedPreferences sharedPreferences;
SharedPreferences.Editor editor;

      PhoneAuthProvider.OnVerificationStateChangedCallbacks mcallback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num = findViewById(R.id.phone);
        otp=findViewById(R.id.otp);
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        f= FirebaseFirestore.getInstance();
        sent=findViewById(R.id.sent);
        check=findViewById(R.id.check);
        auth=FirebaseAuth.getInstance();
        mcallback=new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                Toast.makeText(getApplicationContext(),"verification completed",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
                Toast.makeText(getApplicationContext(),"verification failed"+e,Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                otpcode=s;
                Toast.makeText(getApplicationContext(),"code sent to the number",Toast.LENGTH_LONG).show();
            }
        };

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkacc();
            }
        });
    }
    public void sentSms(View View)
    {
         number=num.getText().toString();
        Toast.makeText(getApplicationContext(),"number:"+number,Toast.LENGTH_LONG).show();
PhoneAuthProvider.getInstance().verifyPhoneNumber(
number,60L, TimeUnit.SECONDS,this,mcallback
);
    }
public void signInPhone(PhoneAuthCredential credential)
{
auth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
    @Override
    public void onComplete(@NonNull Task<AuthResult> task) {
        if(task.isSuccessful() )
        {



checkacc();

        }
        else
        {
            Toast.makeText(getApplicationContext(),"unable to signin",Toast.LENGTH_LONG).show();
        }
    }
});
}
public void checkotp(View view)
{
    String inputotp=otp.getText().toString();


    if(otpcode!=null) {
        verifyPhoneNumber(otpcode,inputotp);
    }

}
public void verifyPhoneNumber(String otp_code,String input_otp)
{
    PhoneAuthCredential credential=PhoneAuthProvider.getCredential(otp_code,input_otp);
   signInPhone(credential);
}
public void checkacc()
{
DocumentReference df=f.collection("name").document(number);
df.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
    @Override
    public void onSuccess(DocumentSnapshot documentSnapshot) {
        if(documentSnapshot.exists())
        {
            String shopid=documentSnapshot.get("shopid").toString();
            editor.putBoolean("login",true);
            editor.putString("phonenumber",number);
            editor.putString("shopid",shopid);
            editor.commit();
            Toast.makeText(getApplicationContext(),"Already Registered Number",Toast.LENGTH_LONG).show();
            startActivity(new Intent(getApplicationContext(),Home.class));
            finish();
        }
        else
        {
            editor.putString("phonenumber",number);
            editor.commit();
            Toast.makeText(getApplicationContext(),"It Seems New Number Please Register your Shop",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(),createAccount.class));
            finish();
        }
    }
});

}
}
