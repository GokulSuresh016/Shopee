package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class productView extends AppCompatActivity {
FirebaseFirestore fb;
DocumentReference dref;
TextView sname,srate;
EditText squantity;
Button btn;
String soldquantity;
Integer soldquantity1,quantity1;
String nname,rate,quantity;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_view);
fb=FirebaseFirestore.getInstance();
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        String number,shopid,branch;
        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");

sname=findViewById(R.id.txt_product);
srate=findViewById(R.id.txt_product1);
squantity=findViewById(R.id.edt_product1);
btn=findViewById(R.id.btn_product);

        Intent i=getIntent();
        final String name=i.getStringExtra("document");
        Toast.makeText(getApplicationContext(),name,Toast.LENGTH_SHORT).show();

        dref=fb.collection("name").document(number).collection(shopid).document(branch).collection("product").document(name);
        dref.get().addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),"error"+e,Toast.LENGTH_SHORT).show();

            }
        }).addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()) {
                    nname = documentSnapshot.get("name").toString();
                    rate = documentSnapshot.get("price").toString();
                    Toast.makeText(getApplicationContext(), "name" + nname, Toast.LENGTH_SHORT).show();
                    quantity = documentSnapshot.get("quantity").toString();
                    sname.setText(nname);
                    srate.setText(rate);
                }else{
                    Toast.makeText(getApplicationContext(),"document do not exist",Toast.LENGTH_SHORT).show();
                }
            }
        });
btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        soldquantity=squantity.getText().toString();
        soldquantity1=Integer.parseInt(soldquantity);
        quantity1=Integer.parseInt(quantity);
        if(soldquantity1 <= quantity1){
            Integer rate1=Integer.parseInt(rate);
            Integer total=rate1*soldquantity1;
            Integer remaing=quantity1-soldquantity1;
            dref.update("quantity",remaing.toString());
            Calendar calendar=Calendar.getInstance();
            SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy");
            final String year=simpleDateFormat.format(calendar.getTime());
            Toast.makeText(getApplicationContext(),"time="+year,Toast.LENGTH_SHORT).show();
            SimpleDateFormat simpleDateFormat1=new SimpleDateFormat("MM");
            final String month=simpleDateFormat1.format(calendar.getTime());
            Toast.makeText(getApplicationContext(),"time="+month,Toast.LENGTH_SHORT).show();
            SimpleDateFormat simpleDateFormat2=new SimpleDateFormat("dd");
            final String day=simpleDateFormat2.format(calendar.getTime());
            Toast.makeText(getApplicationContext(),"time="+day,Toast.LENGTH_SHORT).show();
            SimpleDateFormat simpleDateFormat3=new SimpleDateFormat("hh:mm:ss a");
            final String time=simpleDateFormat3.format(calendar.getTime());
            Toast.makeText(getApplicationContext(),"time="+time,Toast.LENGTH_SHORT).show();
            HashMap<String, String> note=new HashMap<>();
            note.put("Time",time);
            note.put("Product",nname);
            note.put("Quantity",squantity.getText().toString());
            note.put("Amount",total.toString());
            fb.collection("Report").document(year).collection(month).document(day).set(note);
            sname.setText("");
            srate.setText("");
            squantity.setText("");
            Toast.makeText(getApplicationContext(),"successfully updated",Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(productView.this,Home.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(getApplicationContext(),"do not have enough stock",Toast.LENGTH_SHORT).show();
        }
    }
});


    }
}
