package com.example.otpauthentication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Adapter;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import static com.example.otpauthentication.ui.tools.ToolsFragment.day2;
import static com.example.otpauthentication.ui.tools.ToolsFragment.month2;
import static com.example.otpauthentication.ui.tools.ToolsFragment.year2;

public class ReportView extends AppCompatActivity {
    FirebaseFirestore fb;
    CollectionReference ref;
    ArrayList<reportgetter> list;
    RecyclerView.LayoutManager layoutManager;
    AdapterReport adapter;
    RecyclerView view;
 DocumentReference dref;
 reportgetter report;
 Integer mon;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_view);
        fb=FirebaseFirestore.getInstance();
        Toast.makeText(getApplicationContext(),"year"+year2,Toast.LENGTH_SHORT).show();
        mon=Integer.parseInt(month2);
        if(mon<=9){
            month2="0"+mon;
        }

        list=new ArrayList<>();
        view=findViewById(R.id.ReportViewRcle);
        dref=fb.collection("Report").document(year2).collection(month2).document(day2);
        dref.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

               reportgetter  report = documentSnapshot.toObject(reportgetter.class);
                list.add(report);
                report.getProduct();
                Toast.makeText(getApplicationContext(),report.getProduct(),Toast.LENGTH_SHORT).show();
                Log.d("maakachi","product :"+report.getProduct());

                Toast.makeText(getApplicationContext(),"list"+list,Toast.LENGTH_SHORT).show();
                view.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                adapter = new AdapterReport(list);
                view.setAdapter(adapter);
                view.setHasFixedSize(true);
            }

        });

    }

}
