package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

import static android.provider.ContactsContract.CommonDataKinds.*;

public class testing2 extends AppCompatActivity {
    EditText data;
    Button btn,btn1;
    TextView txt;
    FirebaseFirestore fb;
    String data1="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing2);
        fb=FirebaseFirestore.getInstance();
        data=findViewById(R.id.test_edit);
        btn=findViewById(R.id.test_btn);
        btn1=findViewById(R.id.test_btn1);
        txt=findViewById(R.id.test_testView);
         final CollectionReference cref=fb.collection("name");
        DocumentReference dref=fb.document("name/+919526831980");
       /* btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v) {
                String datas=data.getText().toString();
                 Note note=new Note();
                 cref.add(note).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                     @Override
                     public void onSuccess(DocumentReference documentReference) {

                         Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();


                     }
                 }).addOnFailureListener(new OnFailureListener() {
                     @Override
                     public void onFailure(@NonNull Exception e) {
                         Toast.makeText(getApplicationContext(),"failed",Toast.LENGTH_SHORT).show();
                     }
                 });

            }
        });*/
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        try {

                                

                            txt.setText(data1);
                            Toast.makeText(getApplicationContext(),"success"+data1,Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "error" + e, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

    }

}
