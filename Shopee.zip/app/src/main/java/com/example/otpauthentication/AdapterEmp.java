package com.example.otpauthentication;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterEmp extends RecyclerView.Adapter<AdapterEmp.MyViewHoldert> {
 ArrayList<productClass> list;
 public AdapterEmp(ArrayList<productClass> list){
     this.list=list;
 }


    @NonNull
    @Override
    public MyViewHoldert onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
     View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.cardnew,parent,false);
        return new MyViewHoldert(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHoldert holder, final int position) {

     holder.name.setText(list.get(position).getName());
     holder.address.setText(list.get(position).getPrice());
     holder.quantity.setText(list.get(position).getQuantity());
     holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name;
                name=list.get(position).getName();
                Intent intent=new Intent(v.getContext(),productView.class);
                intent.putExtra("document",name);
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHoldert extends RecyclerView.ViewHolder {
    TextView name,address,quantity,path;
    Button btn;
    ImageView imageView;
        public MyViewHoldert(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.namenew);
            address=itemView.findViewById(R.id.addressnew);
            quantity=itemView.findViewById(R.id.numbernew);
            btn=itemView.findViewById(R.id.card_btnew);
            imageView=itemView.findViewById(R.id.img_vnew);



        }
    }


}
