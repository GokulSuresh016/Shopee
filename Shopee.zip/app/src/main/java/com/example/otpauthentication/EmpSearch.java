package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class EmpSearch extends AppCompatActivity {
    DatabaseReference reference;
    ArrayList<productClass> list;
    FirebaseFirestore fb;
    CollectionReference cref;
    RecyclerView recyclerView;
    SearchView searchView;
    AdapterEmp emp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_search);
        try {
            fb=FirebaseFirestore.getInstance();
            cref=fb.collection("name").document("+919526831980").collection("mshop").document("erk").collection("product");
        recyclerView = findViewById(R.id.SearchRecycle);
        list=new ArrayList<>();

        searchView = findViewById(R.id.Searchbar);
        Toast.makeText(getApplicationContext(), "check1", Toast.LENGTH_SHORT).show();

        cref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                    productClass productClass = documentSnapshot.toObject(com.example.otpauthentication.productClass.class);
                    list.add(productClass);
                }
                emp = new AdapterEmp(list);
                recyclerView.setAdapter(emp);
            }
        });

            if(searchView != null){
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {

                        ArrayList<productClass> myList = new ArrayList<>();
                        for (productClass object : list) {
                            if (object.getName().toLowerCase().contains(newText.toLowerCase())) {
                                myList.add(object);

                            }
                            AdapterEmp adapterEmp = new AdapterEmp(myList);
                            recyclerView.setAdapter(adapterEmp);
                        }
                        return true;
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "error" + e, Toast.LENGTH_SHORT).show();
        }
    }



        }

