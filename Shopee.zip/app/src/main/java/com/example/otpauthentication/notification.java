package com.example.otpauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class notification extends AppCompatActivity {

    FirebaseFirestore db;
    CollectionReference cref;
    RecyclerView recyclerView;
    ArrayList<notificationload> list;
    Adapter2 adapter2;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        sharedPreferences=getSharedPreferences("verifyacc",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        String number,shopid,branch;
        number=sharedPreferences.getString("phonenumber","");
        shopid=sharedPreferences.getString("shopid","");
        branch=sharedPreferences.getString("branch","");

        recyclerView=findViewById(R.id.notiRecycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        db=FirebaseFirestore.getInstance();
        cref=db.collection("name").document(number).collection(shopid).document(branch).collection("meassage");
        cref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(queryDocumentSnapshots.isEmpty()){
                    Toast.makeText(getApplicationContext(),"document empty",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    for(DocumentSnapshot documentSnapshot:queryDocumentSnapshots) {
                        notificationload nload = documentSnapshot.toObject(notificationload.class);
                        list.add(nload);
                    }
                    adapter2=new Adapter2(notification.this,list);
                    recyclerView.setAdapter(adapter2);
                        }


                }

        });
    }
}
